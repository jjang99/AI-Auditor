from app.database.repositories.inspection_repository import calculate_score_grade
from rules.core.issue_assessor import BaseIssueAssessor, apply_issue_assessments
from rules.core.models import InspectionSummary, RuleIssue
from rules.core.severity import (
    AssessmentLevel,
    IssueAssessment,
    IssueSeverity,
)


class HighHighAssessor(BaseIssueAssessor):
    def assess(self, issue):
        return IssueAssessment(
            impact=AssessmentLevel.HIGH,
            impact_reason="핵심 업무 영향",
            likelihood=AssessmentLevel.HIGH,
            likelihood_reason="반복 발생 가능",
            severity=IssueSeverity.LOW,
            severity_reason="Matrix가 최종 Severity를 결정",
        )


def _issue(rule_code, severity, line_number=1):
    return RuleIssue(
        rule_code=rule_code,
        rule_name="점수 정책 테스트",
        category="변경영향도",
        severity=severity,
        file_path="sample.docx",
        line_number=line_number,
        evidence="근거",
        description="설명",
    )


def test_calculated_severity_is_used_by_score_flow():
    original = RuleIssue(
        rule_code="TEST-004",
        rule_name="점수 연계 테스트",
        category="감리 사전점검",
        severity="Low",
        file_path="sample.docx",
        line_number=1,
        evidence="근거",
        description="설명",
    )

    assessed_issue = apply_issue_assessments(
        [original],
        HighHighAssessor(),
    )[0]

    summary = InspectionSummary(
        file_count=1,
        rule_count=1,
        executed_rule_count=1,
        issues=(assessed_issue,),
    )

    score, grade = calculate_score_grade(summary)

    assert assessed_issue.severity == "Critical"
    assert score == 80
    assert grade == "B"


def test_score_below_60_uses_frozen_e_grade():
    issues = tuple(
        RuleIssue(
            rule_code=f"TEST-{index:03d}",
            rule_name="등급 기준 테스트",
            category="감리 사전점검",
            severity="Medium",
            file_path="sample.docx",
            line_number=index,
            evidence="근거",
            description="설명",
        )
        for index in range(1, 10)
    )
    summary = InspectionSummary(
        file_count=1,
        rule_count=1,
        executed_rule_count=1,
        issues=issues,
    )

    score, grade = calculate_score_grade(summary)

    assert score == 55
    assert grade == "E"


def test_informational_and_synthesis_findings_do_not_double_penalize_score():
    issues = (
        _issue("CHG-001", "Low", 1),
        _issue("CHG-001", "Medium", 2),
        _issue("CHG-001", "Low", 3),
        _issue("CHG-001", "Medium", 4),
        _issue("CHG-001", "Low", 5),
        _issue("CHG-006", "Medium", 6),
        _issue("AUD-024", "Medium", 7),
    )
    summary = InspectionSummary(
        file_count=3,
        rule_count=20,
        executed_rule_count=20,
        issues=issues,
    )

    score, grade = calculate_score_grade(summary)

    assert score == 95
    assert grade == "A"


def test_real_defect_rule_still_reduces_score():
    summary = InspectionSummary(
        file_count=1,
        rule_count=20,
        executed_rule_count=20,
        issues=(
            _issue("CHG-012", "Medium"),
            _issue("CHG-018", "Medium", 2),
        ),
    )

    score, grade = calculate_score_grade(summary)

    assert score == 95
    assert grade == "A"
