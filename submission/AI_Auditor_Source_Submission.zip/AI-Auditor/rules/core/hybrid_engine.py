import re
from dataclasses import dataclass, replace

from app.parsers.models import ParsedDocument
from rules.core.ai_provider import (
    AIInspectionContext,
    AIInspectionResult,
    BaseAIProvider,
)
from rules.core.ai_strategy import AIProcessingStrategy, get_ai_processing_strategy
from rules.core.models import DocumentRule, RuleExecutionType


@dataclass(frozen=True)
class HybridInspectionContext:
    """Hybrid 검사에서 AI 판단 전에 준비되는 사전분석 정보."""

    document: ParsedDocument
    rule: DocumentRule
    evidence: tuple[str, ...] = ()


class DocumentHybridEngine:
    """Rule 기반 사전분석과 AI 판단을 결합하는 Hybrid 검사 Engine."""

    def __init__(
        self,
        rules: list[DocumentRule] | tuple[DocumentRule, ...],
        provider: BaseAIProvider,
    ):
        self.rules = [
            rule
            for rule in rules
            if rule.enabled
            and rule.execution_type == RuleExecutionType.HYBRID
        ]

        self.provider = provider

    def build_context(
        self,
        document: ParsedDocument,
        rule: DocumentRule,
    ) -> HybridInspectionContext:
        """AI 판단 전에 사용할 공통 Hybrid 검사 Context를 만든다."""

        evidence: tuple[str, ...] = ()

        strategy = get_ai_processing_strategy(rule.code)

        if rule.code == "REQ-003":
            evidence = self._build_req_003_evidence(document)
        elif rule.code == "REQ-018":
            evidence = self._build_req_018_evidence(document)
        elif strategy in (
            AIProcessingStrategy.CANDIDATE,
            AIProcessingStrategy.EVIDENCE,
        ):
            evidence = self._build_relevant_evidence(document, rule)

        return HybridInspectionContext(
            document=document,
            rule=rule,
            evidence=evidence,
        )

    @staticmethod
    def _build_relevant_evidence(
        document: ParsedDocument,
        rule: DocumentRule,
        max_items: int = 12,
        max_chars: int = 4500,
    ) -> tuple[str, ...]:
        """후보/근거확인형 Rule에 관련성이 높은 블록만 전달한다."""

        terms = []
        for value in (rule.name, rule.description, *rule.check_points):
            for term in re.split(r"[\s·/,()]+", str(value)):
                normalized = term.strip("[]{}.,:;'\"")
                if len(normalized) >= 2 and normalized not in terms:
                    terms.append(normalized)

        ranked = []
        for index, block in enumerate(document.blocks):
            text = block.text.strip() if block.text else ""
            if not text:
                continue
            score = sum(1 for term in terms if term.lower() in text.lower())
            if score:
                ranked.append((-score, index, text))

        ranked.sort()
        selected = []
        used = 0
        for _score, _index, text in ranked:
            remaining = max_chars - used
            if remaining <= 0 or len(selected) >= max_items:
                break
            snippet = text[: min(800, remaining)]
            selected.append(snippet)
            used += len(snippet) + 1

        return tuple(selected)

    def _build_req_003_evidence(
        self,
        document: ParsedDocument,
    ) -> tuple[str, ...]:
        """REQ-003: 표현뿐 아니라 정량기준·조건 미구체화 후보도 찾는다."""

        ambiguous_terms = (
            "적절히",
            "필요시",
            "필요 시",
            "가능한 범위",
            "최대한",
            "충분히",
            "신속히",
            "원활히",
        )
        unresolved_terms = (
            "미정",
            "미확정",
            "추후협의",
            "추후 협의",
            "협의 후 확정",
            "협의하여 확정",
            "확정 필요",
            "구체화 필요",
            "불명확",
            "미구체화",
        )
        quantitative_terms = (
            "응답시간",
            "응답 시간",
            "처리시간",
            "처리 시간",
            "처리량",
            "tps",
            "동시접속",
            "동시 접속",
            "동시사용자",
            "동시 사용자",
            "수행횟수",
            "수행 횟수",
            "수행회수",
            "수행 회수",
            "용량",
            "가용률",
            "정확도",
            "성능목표",
            "성능 목표",
            "목표값",
            "목표 값",
        )
        numeric_pattern = re.compile(
            r"\d+(?:\.\d+)?\s*(?:ms|초|분|시간|%|건|회|명|tps|gb|mb|tb)?",
            re.IGNORECASE,
        )
        requirement_id_pattern = re.compile(
            r"\b[A-Z]{2,5}-?\d+(?:-[A-Z0-9]+)*\b",
            re.IGNORECASE,
        )

        evidence: list[str] = []
        seen = set()

        for block in document.blocks:
            text = block.text.strip()

            if not text:
                continue

            matched_terms = [
                term
                for term in (*ambiguous_terms, *unresolved_terms)
                if term in text
            ]
            reasons = []
            if matched_terms:
                reasons.append(f"모호/미확정 표현({', '.join(matched_terms)})")

            matched_metrics = [
                term
                for term in quantitative_terms
                if term.lower() in text.lower()
            ]
            numeric_text = requirement_id_pattern.sub("", text)
            if matched_metrics and not numeric_pattern.search(numeric_text):
                reasons.append(
                    f"정량기준 누락 가능성({', '.join(dict.fromkeys(matched_metrics))})"
                )

            if not reasons:
                continue

            item = f"REQ-003 후보({' / '.join(reasons)}): {text}"
            if item in seen:
                continue
            seen.add(item)
            evidence.append(item)

        return tuple(evidence)

    def _build_req_018_evidence(
        self,
        document: ParsedDocument,
    ) -> tuple[str, ...]:
        """REQ-018: 추적표 헤더를 기준으로 누락 의심행만 AI 후보로 선별한다."""

        evidence: list[str] = []
        trace_columns: dict[str, int] | None = None

        required_groups = {
            "유스케이스": ("유스케이스id", "유스케이스"),
            "화면": ("화면id", "화면"),
            "프로그램": ("프로그램id", "프로그램"),
            "테이블": ("테이블id", "테이블"),
            "통합테스트": ("통합테스트", "시험", "테스트"),
        }

        for block in document.blocks:
            if block.block_type != "sheet_row":
                continue

            text = block.text.strip()
            if not text:
                continue

            # 비기능 요구사항은 화면/프로그램/테이블 등이 본질적으로
            # 적용되지 않을 수 있으므로 기능 추적열의 구조적 누락으로 확정하지 않는다.
            sheet_name = (block.sheet or "").replace(" ", "").lower()
            if "비기능" in sheet_name:
                continue

            cell_values = tuple(block.metadata.get("cell_values", ()))
            columns = (
                [str(value).strip() for value in cell_values]
                if cell_values
                else [value.strip() for value in text.split("|")]
            )
            normalized = [value.lower().replace(" ", "") for value in columns]

            if (
                any("요구사항id" in value for value in normalized)
                and any("통합테스트" in value for value in normalized)
            ):
                trace_columns = {}
                for label, aliases in required_groups.items():
                    # "프로그램"이 "프로그램명"에 먼저 걸리는 식의 부분일치를 막고
                    # ID 열을 우선 선택한다.
                    exact_aliases = tuple(alias.replace(" ", "") for alias in aliases)
                    matched_index = next(
                        (
                            index
                            for index, value in enumerate(normalized)
                            if value in exact_aliases
                        ),
                        None,
                    )
                    if matched_index is None:
                        matched_index = next(
                            (
                                index
                                for index, value in enumerate(normalized)
                                if any(alias in value for alias in aliases)
                            ),
                            None,
                        )
                    if matched_index is not None:
                        trace_columns[label] = matched_index
                continue

            if not trace_columns:
                continue

            first_column = columns[0] if columns else ""
            if not re.match(
                r"^[A-Z]{2,5}-?\d+(?:-[A-Z0-9]+)*$",
                first_column,
                re.IGNORECASE,
            ):
                continue

            # 통합 행이 상세 추적을 별도 SFR 시트로 위임한 경우,
            # 현재 행의 빈 추적열을 누락으로 확정하지 않는다.
            # 참조된 상세 시트는 문서의 다른 행으로 별도 검사된다.
            if any("시트" in value and "참고" in value for value in columns):
                continue

            missing = []
            for label, index in trace_columns.items():
                value = columns[index].strip() if index < len(columns) else ""
                normalized_value = re.sub(r"[.\s/]", "", value).upper()
                companion_value = (
                    columns[index + 1].strip()
                    if label in {"화면", "프로그램"} and index + 1 < len(columns)
                    else ""
                )
                normalized_companion = re.sub(
                    r"[.\s/]", "", companion_value
                ).upper()
                # ID/명칭 쌍 중 어느 한쪽이 N/A이면 해당 추적항목을 비적용으로 본다.
                if (
                    normalized_value == "NA"
                    or normalized_companion == "NA"
                    or ("시트" in value and "참고" in value)
                    or ("시트" in companion_value and "참고" in companion_value)
                ):
                    continue
                if not value:
                    missing.append(label)

            if not missing:
                continue

            location = block.location or block.sheet or "위치 미상"
            evidence.append(
                f"{location}: 추적정보 누락 후보({', '.join(missing)}) | {text[:600]}"
            )

        return tuple(evidence)

    def _build_req_018_findings(
        self,
        context: HybridInspectionContext,
    ) -> AIInspectionResult:
        """REQ-018의 구조적으로 확정된 누락은 Rule 결과로 직접 생성한다."""

        findings = tuple(
            (
                "요구사항 추적정보 누락이 확인되었습니다. "
                + evidence.replace("추적정보 누락 후보", "추적정보 누락")
            )
            for evidence in context.evidence
        )

        return AIInspectionResult(
            rule_code=context.rule.code,
            findings=findings,
            raw_response="",
            provider_name="RulePreanalysis",
        )

    def inspect_document(
        self,
        document: ParsedDocument,
        skip_rule_codes: frozenset[str] = frozenset(),
    ) -> tuple[AIInspectionResult, ...]:
        results: list[AIInspectionResult] = []

        for rule in self.rules:
            if rule.code in skip_rule_codes:
                continue
            context = self.build_context(
                document,
                rule,
            )

            if rule.code == "REQ-018":
                if context.evidence:
                    result = self._build_req_018_findings(context)
                else:
                    result = AIInspectionResult(
                        rule_code=rule.code,
                        findings=(),
                        raw_response="",
                        provider_name=self.provider.__class__.__name__,
                    )
            else:
                strategy = get_ai_processing_strategy(rule.code)
                if strategy in (
                    AIProcessingStrategy.CANDIDATE,
                    AIProcessingStrategy.EVIDENCE,
                ) and not context.evidence:
                    result = AIInspectionResult(
                        rule_code=rule.code,
                        findings=(),
                        raw_response="",
                        provider_name=self.provider.__class__.__name__,
                    )
                else:
                    result = self.provider.inspect(
                        context.document,
                        context.rule,
                        AIInspectionContext(
                            evidence=context.evidence,
                        ),
                    )

            result = replace(
                result,
                execution_type=rule.execution_type.value,
                provider_name=self.provider.__class__.__name__,
            )

            results.append(result)

        return tuple(results)
