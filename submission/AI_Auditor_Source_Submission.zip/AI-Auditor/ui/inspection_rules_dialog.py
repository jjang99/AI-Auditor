import os

from PySide6.QtCore import QEvent, Qt, QSize
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QCheckBox, QDialog, QFrame, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QVBoxLayout, QWidget, QSizePolicy,
)


class InspectionRulesDialog(QDialog):
    def __init__(self, parent=None, category_name=None, rules=None):
        super().__init__(parent)

        self.category_name = category_name or "검사 기준"
        self.rules = rules or []
        self.setWindowTitle(self.category_name)
        self.setModal(True)
        self.setFixedSize(720, 500)
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self._drag_offset = None

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        panel = QFrame()
        panel.setObjectName("rulesDialogPanel")
        outer.addWidget(panel)
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(24, 18, 24, 18)
        layout.setSpacing(8)

        self.header_drag_area = QFrame()
        self.header_drag_area.setObjectName("rulesDialogHeaderArea")
        self.header_drag_area.setFixedHeight(34)
        self.header_drag_area.installEventFilter(self)
        header = QHBoxLayout(self.header_drag_area)
        header.setContentsMargins(0, 0, 0, 0)
        header.setSpacing(8)

        icon_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets", "icons")
        icon = QLabel()
        icon.setObjectName("rulesDialogShieldIcon")
        icon.setPixmap(QIcon(os.path.join(icon_dir, "detail_grade.svg")).pixmap(QSize(22, 22)))
        icon.setAlignment(Qt.AlignCenter)
        icon.setFixedSize(30, 30)
        icon.installEventFilter(self)
        title = QLabel(self.category_name)
        title.setObjectName("rulesDialogTitle")
        title.installEventFilter(self)

        count = QLabel(f"{len(self.rules)}개 규칙")
        count.setObjectName("rulesDialogCount")
        count.installEventFilter(self)
        close_button = QPushButton("×")
        close_button.setObjectName("rulesDialogClose")
        close_button.setFixedSize(30, 30)
        close_button.setCursor(Qt.PointingHandCursor)
        close_button.clicked.connect(self.reject)
        header.addWidget(icon)
        header.addWidget(title)
        header.addWidget(count)
        header.addStretch()
        header.addWidget(close_button)
        layout.addWidget(self.header_drag_area)

        description = QLabel("적용할 항목을 선택하거나 제외할 수 있습니다.")
        description.setObjectName("rulesDialogDescription")
        layout.addWidget(description)
        note = QLabel("※ 변경 사항은 이번 검사에만 적용됩니다.")
        note.setObjectName("rulesDialogNote")
        layout.addWidget(note)

        select_row = QHBoxLayout()
        select_row.setSpacing(8)
        select_row.addStretch()
        select_all = QPushButton("전체 선택")
        select_all.setObjectName("rulesDialogSmallButton")
        select_all.setFixedSize(88, 32)
        select_all.setCursor(Qt.PointingHandCursor)
        select_all.clicked.connect(lambda: self.set_all_checked(True))
        clear_all = QPushButton("전체 해제")
        clear_all.setObjectName("rulesDialogSmallButton")
        clear_all.setFixedSize(88, 32)
        clear_all.setCursor(Qt.PointingHandCursor)
        clear_all.clicked.connect(lambda: self.set_all_checked(False))
        select_row.addWidget(select_all)
        select_row.addWidget(clear_all)
        layout.addLayout(select_row)

        table = QFrame()
        table.setObjectName("rulesTable")
        table_layout = QVBoxLayout(table)
        table_layout.setContentsMargins(0, 0, 0, 0)
        table_layout.setSpacing(0)
        table_header = QFrame()
        table_header.setObjectName("rulesTableHeader")
        table_header.setFixedHeight(34)
        header_layout = QHBoxLayout(table_header)
        header_layout.setContentsMargins(12, 0, 12, 0)
        header_layout.setSpacing(8)
        check_header = QLabel("")
        check_header.setFixedWidth(22)

        code_width = 70
        name_width = 198
        status_width = 52

        code_header = QLabel("코드")
        name_header = QLabel("규칙 제목")
        desc_header = QLabel("설명")
        status_header = QLabel("상태")

        for label in (code_header, name_header, desc_header, status_header):
            label.setObjectName("rulesTableHeaderText")

        code_header.setAlignment(Qt.AlignCenter)
        name_header.setAlignment(Qt.AlignCenter)
        desc_header.setAlignment(Qt.AlignCenter)
        status_header.setAlignment(Qt.AlignCenter)

        code_header.setFixedWidth(code_width)
        name_header.setFixedWidth(name_width)
        status_header.setFixedWidth(status_width)

        header_layout.addWidget(check_header)
        header_layout.addWidget(code_header)
        header_layout.addWidget(name_header)
        header_layout.addWidget(desc_header, 1)
        header_layout.addWidget(status_header)
        table_layout.addWidget(table_header)

        scroll = QScrollArea()
        scroll.setObjectName("rulesTableScroll")
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        list_content = QWidget()
        list_content.setObjectName("rulesListContent")
        list_layout = QVBoxLayout(list_content)
        list_layout.setContentsMargins(0, 0, 0, 0)
        list_layout.setSpacing(0)

        self.rule_checkboxes = []
        self.state_labels = []
        for rule in self.rules:
            code = rule.code
            name = rule.name
            desc = rule.description
            checked = True

            row = QFrame()
            row.setObjectName("rulesTableRow")
            row.setFixedHeight(36)
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(12, 0, 4, 0)
            row_layout.setSpacing(8)
            checkbox = QCheckBox()
            checkbox.setObjectName("rulesCheckbox")
            checkbox.setChecked(checked)
            checkbox.setCursor(Qt.PointingHandCursor)
            checkbox.setFixedWidth(22)
            self.rule_checkboxes.append(checkbox)
            code_label = QLabel(code)
            code_label.setObjectName("rulesRowCode")
            code_label.setFixedWidth(code_width)
            code_label.setAlignment(Qt.AlignCenter)

            name_label = QLabel(name)
            name_label.setObjectName("rulesRowText")
            name_label.setFixedWidth(name_width)
            name_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)

            desc_label = QLabel(desc)
            desc_label.setObjectName("rulesRowDescription")
            desc_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            # 긴 설명이 상태 열을 오른쪽으로 밀지 않도록 설명 열만 가변 축소
            desc_label.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)

            state_label = QLabel("활성" if checked else "비활성")
            state_label.setObjectName("rulesRowState")
            state_label.setFixedWidth(status_width)
            state_label.setAlignment(Qt.AlignCenter)
            self.state_labels.append(state_label)
            checkbox.stateChanged.connect(lambda state, label=state_label: label.setText("활성" if state == Qt.Checked.value else "비활성"))
            checkbox.stateChanged.connect(self.update_selected_count)
            row_layout.addWidget(checkbox)
            row_layout.addWidget(code_label)
            row_layout.addWidget(name_label)
            row_layout.addWidget(desc_label, 1)
            row_layout.addWidget(state_label)

            list_layout.addWidget(row)

        list_layout.addStretch()
        scroll.setWidget(list_content)
        table_layout.addWidget(scroll, 1)
        layout.addWidget(table, 1)

        bottom = QHBoxLayout()
        bottom.setSpacing(10)
        self.selected_count = QLabel()
        self.selected_count.setObjectName("rulesSelectedCount")
        self.update_selected_count()
        cancel = QPushButton("취소")
        cancel.setObjectName("rulesCancelButton")
        cancel.setFixedSize(96, 32)
        cancel.setCursor(Qt.PointingHandCursor)
        cancel.clicked.connect(self.reject)
        confirm = QPushButton("확인")
        confirm.setObjectName("rulesConfirmButton")
        confirm.setFixedSize(96, 32)
        confirm.setCursor(Qt.PointingHandCursor)
        confirm.clicked.connect(self.accept)
        bottom.addWidget(self.selected_count)
        bottom.addStretch()
        bottom.addWidget(cancel)
        bottom.addWidget(confirm)
        layout.addLayout(bottom)
        self.apply_theme()

    def set_all_checked(self, checked):
        for checkbox in self.rule_checkboxes:
            checkbox.setChecked(checked)

    def update_selected_count(self):
        selected = sum(
            1 for checkbox in self.rule_checkboxes
            if checkbox.isChecked()
        )
        total = len(self.rule_checkboxes)
        self.selected_count.setText(
            f"선택됨 {selected} / {total} 규칙"
        )

    def eventFilter(self, watched, event):
        draggable = watched is self.header_drag_area or watched.objectName() in {"rulesDialogShieldIcon", "rulesDialogTitle", "rulesDialogCount"}
        if draggable:
            if event.type() == QEvent.MouseButtonPress and event.button() == Qt.LeftButton:
                self._drag_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
                return True
            if event.type() == QEvent.MouseMove and self._drag_offset is not None and event.buttons() & Qt.LeftButton:
                self.move(event.globalPosition().toPoint() - self._drag_offset)
                return True
            if event.type() == QEvent.MouseButtonRelease and event.button() == Qt.LeftButton:
                self._drag_offset = None
                return True
        return super().eventFilter(watched, event)

    def apply_theme(self):
        host = self.parentWidget().window() if self.parentWidget() is not None else None
        is_dark = getattr(host, "is_dark_mode", True)
        if is_dark:
            self.setStyleSheet("""
                #rulesDialogPanel { background:#101f2c; border:1px solid #64748b; border-radius:12px; }
                #rulesDialogHeaderArea, #rulesListContent { background:transparent; }
                #rulesDialogShieldIcon { background:transparent; border:none; }
                #rulesDialogTitle { color:#ffffff; font-size:20px; font-weight:800; }
                #rulesDialogCount { color:#b8c5d4; font-size:12px; font-weight:700; }
                #rulesDialogClose { color:#ffffff; background:transparent; border:none; font-size:24px; font-weight:650; }
                #rulesDialogClose:hover { background:#1d3142; border-radius:6px; }
                #rulesDialogDescription { color:#f1f5f9; font-size:12px; font-weight:650; }
                #rulesDialogNote { color:#60a5fa; font-size:11px; font-weight:750; }
                #rulesDialogSmallButton, #rulesCancelButton { color:#ffffff; background:#253b4f; border:1px solid #476079; border-radius:7px; font-size:12px; font-weight:750; }
                #rulesDialogSmallButton:hover, #rulesCancelButton:hover { background:#30495f; }
                #rulesConfirmButton { color:#ffffff; background:#2563eb; border:none; border-radius:7px; font-size:12px; font-weight:850; }
                #rulesConfirmButton:hover { background:#3475f5; }
                #rulesTable { background:#0d1721; border:1px solid #40586c; border-radius:8px; }
                #rulesTableHeader { background:#17293a; border-bottom:1px solid #40586c; }
                #rulesTableHeaderText { color:#d9e3ee; font-size:11px; font-weight:800; }
                #rulesTableRow { background:#0d1721; border-bottom:1px solid #293d50; }
                #rulesTableRow:hover { background:#142536; }
                #rulesRowText { color:#ffffff; font-size:11px; font-weight:750; }
                #rulesRowDescription { color:#d7e0e9; font-size:11px; font-weight:600; }
                #rulesRowState { color:#ffffff; font-size:11px; font-weight:750; }
                #rulesSelectedCount { color:#ffffff; font-size:12px; font-weight:800; }
                #rulesTableScroll { background:transparent; border:none; }
                #rulesTableScroll QWidget { background:transparent; }
                #rulesTableScroll QScrollBar:vertical { background:transparent; width:8px; margin:2px; }
                #rulesTableScroll QScrollBar::handle:vertical { background:#60758a; min-height:28px; border-radius:4px; }
                #rulesTableScroll QScrollBar::add-line:vertical, #rulesTableScroll QScrollBar::sub-line:vertical { height:0px; }
                QCheckBox#rulesCheckbox { background:transparent; spacing:0px; }
                QCheckBox#rulesCheckbox::indicator { width:18px; height:18px; }
            """)
        else:
            self.setStyleSheet("""
                #rulesDialogPanel { background:#ffffff; border:1px solid #a8b6c7; border-radius:12px; }
                #rulesDialogHeaderArea, #rulesListContent { background:transparent; }
                #rulesDialogShieldIcon { background:transparent; border:none; }
                #rulesDialogTitle { color:#050b16; font-size:20px; font-weight:800; }
                #rulesDialogCount { color:#475569; font-size:12px; font-weight:700; }
                #rulesDialogClose { color:#0f172a; background:transparent; border:none; font-size:24px; font-weight:650; }
                #rulesDialogClose:hover { background:#eef2f6; border-radius:6px; }
                #rulesDialogDescription { color:#111827; font-size:12px; font-weight:650; }
                #rulesDialogNote { color:#1d4ed8; font-size:11px; font-weight:750; }
                #rulesDialogSmallButton, #rulesCancelButton { color:#0f172a; background:#e7edf4; border:1px solid #bdc9d6; border-radius:7px; font-size:12px; font-weight:750; }
                #rulesDialogSmallButton:hover, #rulesCancelButton:hover { background:#dce5ee; }
                #rulesConfirmButton { color:#ffffff; background:#2563eb; border:none; border-radius:7px; font-size:12px; font-weight:850; }
                #rulesConfirmButton:hover { background:#1d4ed8; }
                #rulesTable { background:#ffffff; border:1px solid #b9c6d5; border-radius:8px; }
                #rulesTableHeader { background:#eef3f8; border-bottom:1px solid #b9c6d5; }
                #rulesTableHeaderText { color:#263548; font-size:11px; font-weight:800; }
                #rulesTableRow { background:#ffffff; border-bottom:1px solid #d9e1ea; }
                #rulesTableRow:hover { background:#f6f9fc; }
                #rulesRowText { color:#0b1220; font-size:11px; font-weight:750; }
                #rulesRowDescription { color:#334155; font-size:11px; font-weight:600; }
                #rulesRowState { color:#0f172a; font-size:11px; font-weight:750; }
                #rulesSelectedCount { color:#0f172a; font-size:12px; font-weight:800; }
                #rulesTableScroll { background:transparent; border:none; }
                #rulesTableScroll QWidget { background:transparent; }
                #rulesTableScroll QScrollBar:vertical { background:transparent; width:8px; margin:2px; }
                #rulesTableScroll QScrollBar::handle:vertical { background:#8998aa; min-height:28px; border-radius:4px; }
                #rulesTableScroll QScrollBar::add-line:vertical, #rulesTableScroll QScrollBar::sub-line:vertical { height:0px; }
                QCheckBox#rulesCheckbox { background:transparent; spacing:0px; }
                QCheckBox#rulesCheckbox::indicator { width:18px; height:18px; }
            """)